﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 

namespace obligatorio3
{
    static class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bienvenido a Social.NetWork ");
            Sistema sistema = Sistema.Instancia;
            sistema.PrecargaDeDatos();

            while (true)
            {
                Console.WriteLine("Seleccione las opciones del 1 al 5 ");
                Console.WriteLine("1 - Alta de miembro");
                Console.WriteLine("2 - Publicaciones de un miembro");
                Console.WriteLine("3 - Reacciones de un miembro");
                Console.WriteLine("4 - Posts realizados entre 2 fechas elegidas");
                Console.WriteLine("5 - Miembros que hayan realizado más publicaciones");
                Console.WriteLine("Enter - Salir del programa");

                Console.Write("Ingrese su opción (o presione Enter para salir): ");
                string opcionStr = Console.ReadLine();

                if (string.IsNullOrEmpty(opcionStr))
                {
                    Console.WriteLine("Saliendo del programa...");
                    break;
                }

                if (int.TryParse(opcionStr, out int opcion))
                {
                    Console.Clear();

                    switch (opcion)
                    {
                        case 1:
                            Sistema sist = Sistema.Instancia;
                            Console.WriteLine("Seleccionaste la Opción 1");
                            string email, contraseña, nombre, apellido;
                            DateTime fechaNacimiento;


                            do
                            {
                                Console.WriteLine("Email (No dejar campo vacio): ");
                                email = Console.ReadLine();
                                foreach (Miembro miem in sist.miembros)
                                    if (email == miem.Email)
                                    {
                                        Console.WriteLine("Email ya existe");
                                        email = "";
                                    }

                            } while (string.IsNullOrEmpty(email));

                            do
                            {
                                Console.WriteLine("Contraseña(No dejar campo vacio): ");
                                contraseña = Console.ReadLine();
                            } while (string.IsNullOrEmpty(contraseña));

                            do
                            {
                                Console.WriteLine("Nombre(No dejar campo vacio): ");
                                nombre = Console.ReadLine();
                            } while (string.IsNullOrEmpty(nombre));

                            do
                            {
                                Console.WriteLine("Apellido(No dejar campo vacio): ");
                                apellido = Console.ReadLine();
                            } while (string.IsNullOrEmpty(apellido));

                            do
                            {
                                Console.WriteLine("Ingrese su fecha de nacimiento (yyyy-MM-dd)(No dejar campo vacio):");
                                string fechaNacimientoStr = Console.ReadLine();

                                if (DateTime.TryParseExact(fechaNacimientoStr, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out fechaNacimiento))
                                {
                                    Console.WriteLine("Fecha de nacimiento válida: " + fechaNacimiento.ToShortDateString());
                                }
                                else
                                {
                                    Console.WriteLine("Formato de fecha incorrecto. Por favor, ingrese una fecha válida en el formato yyyy-MM-dd.");
                                }
                            } while (fechaNacimiento == DateTime.MinValue);

                            Console.WriteLine("Miembro registrado con éxito.");
                            Miembro nuevoMiembro = new Miembro(email, contraseña, nombre, apellido, fechaNacimiento, false);
                            sistema.miembros.Add(nuevoMiembro);
                            foreach (Miembro m in sistema.miembros)
                                if (email == m.Email)
                                {
                                    Console.WriteLine(m.Nombre);
                                }


                            break;
                        case 2:
                            Console.WriteLine("Seleccionaste la Opción 2");
                            ListarPublicacionesPorEmail();
                            break;
                        case 3:
                            Console.WriteLine("Seleccionaste la Opción 3");
                            ListarPostConComentariosPorEmail();
                            break;
                        case 4:
                            Console.WriteLine("Seleccionaste la Opción 4");
                            ListarPostsPorRangoDeFechas();
                            break;
                        case 5:
                            Console.WriteLine("Seleccionaste la Opción 5");
                            ObtenerMiembrosConMasPublicaciones();
                            break;
                        default:
                            Console.WriteLine("Opción no válida");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Entrada no válida. Por favor, ingrese un número válido.");
                }
            }
        }



        static void ListarPublicacionesPorEmail()
        {
            string email;
            Sistema sist = Sistema.Instancia;

            do
            {
                Console.WriteLine("Ingrese el email del miembro: ");
                email = Console.ReadLine();
            } while (string.IsNullOrEmpty(email));

            bool encontrado = false; 

            foreach (Miembro miem in sist.miembros)
            {
                if (email == miem.Email)
                {
                    encontrado = true; 
                    Console.WriteLine("Miembro encontrado:");

                    if (miem.Posts.Count == 0)
                    {
                        Console.WriteLine("El usuario no tiene publicaciones.");
                    }
                    else
                    {
                        foreach (Post post in miem.Posts)
                        {
                            Console.WriteLine("Post con título: " + post.Titulo);
                            foreach (Comentario coment in post.Comentarios)
                            {
                                Console.WriteLine("Comentario con id: " + coment.Id);
                            }
                        }
                    }
                }
            }

            if (!encontrado)
            {
                Console.WriteLine("No se encontraron miembros con el email especificado.");
            }
        }


        static void ListarPostConComentariosPorEmail()
        {
            Console.WriteLine("Ingrese el email del miembro: ");
            string email = Console.ReadLine();
            Sistema sist = Sistema.Instancia;

            bool encontrado = false;
            foreach (Miembro miem in sist.miembros)
            {
                if (email == miem.Email)
                {
                    encontrado = true;
                    Console.WriteLine("Miembro encontrado:");

                    bool tieneComentarios = false;
                    foreach (Post post in sist.posts)
                    {
                        foreach (Comentario coment in post.Comentarios)
                        {
                            if (email == coment.Autor.Email)
                            {
                                Console.WriteLine("Post comentado con titulo: " + post.Titulo);
                                tieneComentarios = true; 
                            }
                        }
                    }

                    if (!tieneComentarios)
                    {
                        Console.WriteLine("El miembro no ha realizado comentarios.");
                    }
                }
            }

            if (!encontrado)
            {
                Console.WriteLine("No se encontró un miembro con el email especificado.");
            }
        }

        static void ListarPostsPorRangoDeFechas()
        {
            Sistema sistema = Sistema.Instancia;

            DateTime fecha1;
            do
            {
                Console.WriteLine("Ingrese Fecha1 (yyyy-MM-dd)(No dejar campo vacío):");
                string fecha1Strg = Console.ReadLine();

                if (DateTime.TryParseExact(fecha1Strg, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out fecha1))
                {
                    Console.WriteLine("Fecha válida: " + fecha1.ToShortDateString());
                }
                else
                {
                    Console.WriteLine("Formato de fecha incorrecto. Por favor, ingrese una fecha válida en el formato yyyy-MM-dd.");
                }
            } while (fecha1 == DateTime.MinValue);

            DateTime fecha2;
            do
            {
                Console.WriteLine("Ingrese Fecha2 (yyyy-MM-dd):");
                string fecha2Strg = Console.ReadLine();

                if (DateTime.TryParseExact(fecha2Strg, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out fecha2))
                {
                    Console.WriteLine("Fecha válida: " + fecha2.ToShortDateString());
                }
                else
                {
                    Console.WriteLine("Formato de fecha incorrecto. Por favor, ingrese una fecha válida en el formato yyyy-MM-dd.");
                }
            } while (fecha2 == DateTime.MinValue);

            bool seEncontraronPublicaciones = false;

            foreach (Post post in sistema.posts)
            {
                if (post.Fecha >= fecha1 && post.Fecha <= fecha2)
                {
                    Console.WriteLine($"Los post entre fechas son  {post.Titulo} {post.Id} {post.Contenido}  {post.Fecha} ");
                    seEncontraronPublicaciones = true;
                }
            }

            if (!seEncontraronPublicaciones)
            {
                Console.WriteLine("No se encontraron publicaciones entre las fechas especificadas.");
            }
        }

        static void ObtenerMiembrosConMasPublicaciones()
        {
            int cantMax = 0;
            Sistema sist = Sistema.Instancia;
            foreach (Miembro miem in sist.miembros)
            {
                if ((miem.Posts.Count + miem.Comentarios.Count) > cantMax)
                {
                    cantMax = miem.Posts.Count + miem.Comentarios.Count;
                }
            }
            foreach (Miembro miem in sist.miembros)
            {
                if ((miem.Posts.Count + miem.Comentarios.Count) == cantMax)
                {
                    Console.WriteLine("Miembro con Email: " + miem.Email + " contiene " + cantMax + " publicaciones.");
                    foreach (Post post in miem.Posts)

                        Console.WriteLine("Post con titulo: " + post.Titulo);


                    foreach (Comentario coment in miem.Comentarios)
                    {
                        Console.WriteLine("Comentario con id: " + coment.Id);

                    }
                }


            }
        }
    }



}