﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace obligatorio3
{
    public abstract class Usuario
    {
        public string Email { get; set; }
        public string Contraseña { get; set; }

        public Usuario(string email, string contraseña)
        {
            Email = email;
            Contraseña = contraseña;
        }


    }
}