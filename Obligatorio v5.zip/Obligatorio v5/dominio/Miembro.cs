﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static obligatorio3.Reaccion;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace obligatorio3
{
    public class Miembro : Usuario
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public bool Bloqueado { get; set; }
        public List<Miembro> ListaDeAmigos { get; }
        public List<Invitacion> ListaDeInvitaciones { get; }
        public List<Post> Posts { get; }
        public List<Comentario> Comentarios { get; }

        public Miembro(string email, string contraseña, string nombre, string apellido, DateTime fechaNacimiento, bool bloqueado)
            :base(email, contraseña)
        {
         
            Email = email;
            Contraseña = contraseña;
            Nombre = nombre;
            Apellido = apellido;
            FechaNacimiento = fechaNacimiento;
            Bloqueado = bloqueado;
            ListaDeAmigos = new List<Miembro>();
            Posts = new List<Post>();
            Comentarios = new List<Comentario>();
        }
     
        public void AnadirAmigo(Miembro miembro)
        {
            ListaDeAmigos.Add(miembro);
        }
        public void AnadirPost(Post post)
        {
            Posts.Add(post);
        }

        public void EnviarSolicitudAmistad(Miembro solicitante, Miembro destinatario)
        {
            if (solicitante.Bloqueado)
            {
                Console.WriteLine("No puedes enviar solicitudes de amistad porque estás bloqueado.");
                return;
            }

            if (destinatario.Bloqueado)
            {
                Console.WriteLine("No puedes enviar una solicitud de amistad a alguien que está bloqueado.");
                return;
            }
            Invitacion invitacion = new Invitacion(solicitante, destinatario);
            destinatario.ListaDeInvitaciones.Add(invitacion);
         
        }

        public void aceptarSolicitudDeAmistad(Miembro solicitante)
        {
            foreach (Invitacion invite in ListaDeInvitaciones)
            {
                if (invite.usuarioSolicitante == solicitante)
                    invite.AceptarInvitacion();
            }
            
        }
        public void PublicarPost(Post post)
        {
            if (Bloqueado)
            {
                Console.WriteLine("No puedes publicar un post porque estás bloqueado.");
                return;
            }

        }

       
        public void AltaMiembro()
        {
            Console.Write("Email: ");
            string email = Console.ReadLine();
            if (email == "")
            {
                Console.WriteLine("No puede ingresar un email vacio.");
            }
            Console.Write("Contraseña: ");
            string contraseña = Console.ReadLine();
            if (contraseña == "")
            {
                Console.WriteLine("No puede ingresar una contraseña vacia.");
            }
            Console.Write("Nombre: ");
            string nombre = Console.ReadLine();
            if (nombre == "")
            {
                Console.WriteLine("No puede ingresar un nombre vacio.");
            }
            Console.Write("Apellido: ");
            string apellido = Console.ReadLine();
            if (apellido == "")
            {
                Console.WriteLine("No puede ingresar un apellido vacio.");
            }
            Console.Write("Fecha de Nacimiento (yyyy-MM-dd): ");

            Console.WriteLine("Miembro registrado con éxito.");



        }
    }

}