﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace obligatorio3
{
    public class Post : Publicacion
    {
        public string Titulo { get; set; }
        public string NombreImagen { get; set; }
        public bool EsPublico { get; set; }
        public bool Censurado { get; set; }
        public List<Comentario> Comentarios { get; }
        public List<Reaccion> Reacciones { get; }

        public Post(int id, Miembro autor, string titulo, string contenido, string nombreImagen, bool esPublico, DateTime fecha)
            : base(id, autor, contenido)
        {
            Titulo = titulo;
            NombreImagen = nombreImagen;
            EsPublico = esPublico;
            Censurado = false;
            Comentarios = new List<Comentario>();
            Reacciones = new List<Reaccion>();
            autor.Posts.Add(this);
            Fecha = fecha;
        }

      public void anadirComentario(Comentario comentario)
        {
            Comentarios.Add(comentario);
        }
        public void agregarReaccion(Reaccion reaccion)
        {
            Reacciones.Add(reaccion);
        }
        public int calcularVA()
        {
            int valorVA;
 
            int cantLikes = 0;
            int cantDislikes = 0;

            foreach(Reaccion react in Reacciones)
            {
                if (react.EsLike == true) cantLikes++;
                else cantDislikes++;
            }
            valorVA = (-2 * cantDislikes) +(5 * cantLikes) ;

            if (EsPublico) valorVA += 10;

            return valorVA;
        }
    }
}