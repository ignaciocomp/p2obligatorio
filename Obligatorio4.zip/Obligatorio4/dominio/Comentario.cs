﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static obligatorio3.Reaccion;

namespace obligatorio3
{
    public class Comentario : Publicacion
{
   // private Post _postAsociado;
    public bool EsPublico { get; set; }
    public List<Reaccion> Reacciones { get; } = new List<Reaccion>();

    public Comentario(int id,Miembro autor,string contenido,string titulo, bool esPublico)
        : base(id, autor, contenido)
    {
        EsPublico = esPublico;
        Reacciones = new List<Reaccion>();
            autor.Comentarios.Add(this);
        //_postAsociado = postAsociado;
    }
        public void agregarReaccion(Reaccion reaccion)
        {
            Reacciones.Add(reaccion);
        }
        public int calcularVA()
        {
            int valorVA;

            int cantLikes = 0;
            int cantDislikes = 0;

            foreach (Reaccion react in Reacciones)
            {
                if (react.EsLike == true) cantLikes++;
                else cantDislikes++;
            }
            valorVA = (-2 * cantDislikes) + (5 * cantLikes);

            return valorVA;
        }
        //public Post GetPost() { return _postAsociado; }
    }
}