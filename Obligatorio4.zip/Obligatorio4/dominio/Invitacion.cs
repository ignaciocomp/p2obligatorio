﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace obligatorio3
{
    public class Invitacion
    {
        public static int UltimoId = 0;
        public int Id { get; set; }
        public Miembro usuarioSolicitante { get; set; }
        public Miembro usuarioDestinatario { get; set; }
        public EstadoInvitacion Estado { get; set; }
        public DateTime fechaSolicitud { get; set; }

        public Invitacion(Miembro solicitante, Miembro destinatario)
        {
            Id = UltimoId;
            ++Id;
            UltimoId = Id;
            usuarioSolicitante = solicitante;
            usuarioDestinatario = destinatario;
            Estado = EstadoInvitacion.PENDIENTE_APROBACION;
            fechaSolicitud = DateTime.Now;
        }

        public enum EstadoInvitacion
        {
            PENDIENTE_APROBACION,
            APROBADA,
            RECHAZADA
        }
        public void AceptarInvitacion()
        {
            Estado = EstadoInvitacion.APROBADA;
            usuarioSolicitante.ListaDeAmigos.Add(usuarioDestinatario);
            usuarioDestinatario.ListaDeAmigos.Add(usuarioSolicitante);
        }
        public void RechazarInvitacion()
        {
            Estado = EstadoInvitacion.RECHAZADA;
        }
    }
}