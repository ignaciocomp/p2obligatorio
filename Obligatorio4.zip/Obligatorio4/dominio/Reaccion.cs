﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace obligatorio3
{
    public class Reaccion
    {
        
        public bool EsLike { get; set; }
        public Miembro Miembro { get; set; }

        public Reaccion(bool esLike, Miembro miembro)
        {
            EsLike = esLike;
            Miembro = miembro;
        }
        //no sabia como ponerlo en el constructor asi que puse esto equis de
         
    }
}
