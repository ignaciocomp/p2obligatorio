﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace obligatorio3
{
    public abstract class Publicacion
    {
        public int Id { get; set; }
        public Miembro Autor { get; set; }
        public DateTime Fecha { get; set; }
        public string Contenido { get; set; }
        public List<Reaccion> Reacciones { get; set; }

        public Publicacion(int id, Miembro autor, string contenido)
        {
            Id = id;
            Autor = autor;
            Fecha = DateTime.Now;
            Contenido = contenido;
            Reacciones = new List<Reaccion>();
        }
    }
}