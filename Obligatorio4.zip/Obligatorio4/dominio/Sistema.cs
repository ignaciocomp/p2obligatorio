﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
 
namespace obligatorio3
{
    public class Sistema
    {
        public List<Miembro> miembros = new List<Miembro>();
        public List<Administrador> administradores = new List<Administrador>();
        public List<Invitacion> invitaciones = new List<Invitacion>();
        public List<Post> posts = new List<Post>();
        public List<Reaccion> reacciones = new List<Reaccion>();
        public List<Comentario> comentarios = new List<Comentario>();
        private static Sistema instancia;
            

        public static Sistema Instancia
        {
            get
            {
                if (instancia == null)
                {
                    instancia = new Sistema();

                }
                return instancia;
            }

        }

        public Sistema()
        {
          
        }

        public void PrecargaDeDatos()
        {

            Miembro miembro1 = new Miembro("cmendez@gmail.com", "Carlos123", "Carlos", "Mendez", new DateTime(2001, 5, 15),false);
            Miembro miembro2 = new Miembro("jrodriguez@gmail.com", "Josefina123", "Josefina", "Rodriguez", new DateTime(1968, 8, 22), false);
            Miembro miembro3 = new Miembro("lperez@gmail.com", "Luisa123", "Luisa", "Perez", new DateTime(1992, 3, 10), false);
            Miembro miembro4 = new Miembro("avazquez@gmail.com", "Alejandro123", "Alejandro", "Vazquez", new DateTime(1995, 7, 5), false);
            Miembro miembro5 = new Miembro("mlopez@gmail.com", "Milagros123", "Milagros", "Lopez", new DateTime(1987, 11, 30), false);
            Miembro miembro6 = new Miembro("lgomez@gmail.com", "Laura123", "Laura", "Gomez", new DateTime(2000, 4, 18), false);
            Miembro miembro7 = new Miembro("adiaz@gmail.com", "Alberto123", "Alberto", "Diaz", new DateTime(1990, 9, 7), false);
            Miembro miembro8 = new Miembro("agonzales@gmail.com", "Maria123", "Maria", "Gonzales", new DateTime(1985, 12, 12), false);
            Miembro miembro9 = new Miembro("jcarrion@gmail.com", "Jorge123", "Jorge", "Carrion", new DateTime(2004, 1, 25), false);
            Miembro miembro10 = new Miembro("ecompañ@gmail.com", "Elena123", "Elena", "Compañ", new DateTime(1989, 6, 8), false);

            miembros.Add(miembro1);
            miembros.Add(miembro2);
            miembros.Add(miembro3);
            miembros.Add(miembro4);
            miembros.Add(miembro5);
            miembros.Add(miembro6);
            miembros.Add(miembro7);
            miembros.Add(miembro8);
            miembros.Add(miembro9);
            miembros.Add(miembro10);

            Invitacion invitacion1 = new Invitacion(miembro7, miembro9);
            Invitacion invitacion2 = new Invitacion( miembro8, miembro3);
            Invitacion invitacion3 = new Invitacion( miembro2, miembro4);
            Invitacion invitacion4 = new Invitacion( miembro5, miembro6);
            Invitacion invitacion5 = new Invitacion( miembro1, miembro10);

            invitacion1.Estado = Invitacion.EstadoInvitacion.APROBADA;
            invitacion2.Estado = Invitacion.EstadoInvitacion.RECHAZADA;
            invitacion3.Estado = Invitacion.EstadoInvitacion.PENDIENTE_APROBACION;
            invitacion4.Estado = Invitacion.EstadoInvitacion.PENDIENTE_APROBACION;
            invitacion5.Estado = Invitacion.EstadoInvitacion.APROBADA;

            invitaciones.Add(invitacion1);
            invitaciones.Add(invitacion2);
            invitaciones.Add(invitacion3);
            invitaciones.Add(invitacion4);
            invitaciones.Add(invitacion5);


            Post post1 = new Post(1, miembro1, "Título Post 1", "Contenido Post 1", "imagen1.jpg", true, new DateTime(2023, 9, 7));
            Post post2 = new Post(2, miembro3, "Título Post 2", "Contenido Post 2", "imagen2.jpg", false, new DateTime(2023, 1, 7));
            Post post3 = new Post(3, miembro4, "Título Post 3", "Contenido Post 3", "imagen3.jpg", true, new DateTime(2023, 4, 7));
            Post post4 = new Post(4, miembro5, "Título Post 4", "Contenido Post 4", "imagen4.jpg", false, new DateTime(2023, 5, 7));
            Post post5 = new Post(5, miembro4, "Título Post 5", "Contenido Post 5", "imagen5.jpg", true, new DateTime(2023, 6, 7));

            posts.Add(post1);
            posts.Add(post2);
            posts.Add(post3);
            posts.Add(post4);
            posts.Add(post5);

            Comentario comentario1 = new Comentario(1, miembro2, "Primer comentario Post 1","titulo", false);
            Comentario comentario2 = new Comentario(2, miembro3, "Segundo comentario Post 1", "titulo", false);
            Comentario comentario3 = new Comentario(3, miembro10, "Tercer comentario Post 1","titulo", false);
            Comentario comentario4 = new Comentario(4, miembro4, "Primer comentario Post 2", "titulo", false);
            Comentario comentario5 = new Comentario(5, miembro9, "Segundo comentario Post 2", "titulo", false);
            Comentario comentario6 = new Comentario(6, miembro2, "Tercer comentario Post 2", "titulo", false);
            Comentario comentario7 = new Comentario(7, miembro6, "Primer comentario Post 3", "titulo", false);
            Comentario comentario8 = new Comentario(8, miembro1, "Segundo comentario Post 3", "titulo", false);
            Comentario comentario9 = new Comentario(9, miembro4, "Tercer comentario Post 3", "titulo", false);
            Comentario comentario10 = new Comentario(10, miembro6, "Primer comentario Post 4", "titulo", false);
            Comentario comentario11 = new Comentario(11, miembro7, "Segundo comentario Post 4", "titulo", false);
            Comentario comentario12 = new Comentario(12, miembro4, "Tercer comentario Post 4", "titulo", false);
            Comentario comentario13 = new Comentario(13, miembro1, "Primer comentario Post 5", "titulo", false);
            Comentario comentario14 = new Comentario(14, miembro5, "Segundo comentario Post 5", "titulo", false);
            Comentario comentario15 = new Comentario(15, miembro10, "Tercer comentario Post 5", "titulo", false);
            post1.anadirComentario(comentario1);
            post1.anadirComentario(comentario2);
            post1.anadirComentario(comentario3);
            post1.anadirComentario(comentario4);
            post1.anadirComentario(comentario5);
            post2.anadirComentario(comentario6);
            post2.anadirComentario(comentario7);
            post2.anadirComentario(comentario8);
            post3.anadirComentario(comentario9);
            post3.anadirComentario(comentario10);
            post4.anadirComentario(comentario11);
            post4.anadirComentario(comentario12);
            post5.anadirComentario(comentario13);
            post5.anadirComentario(comentario14);
            post5.anadirComentario(comentario15);

            Reaccion reaccion1 = new Reaccion(false, miembro2);
            Reaccion reaccion2 = new Reaccion(false, miembro5);
            Reaccion reaccion3 = new Reaccion(true, miembro4);
            Reaccion reaccion4 = new Reaccion(true, miembro7);



            post1.agregarReaccion(reaccion1);
            post3.agregarReaccion(reaccion4);
            comentario12.agregarReaccion(reaccion2);
            comentario9.agregarReaccion(reaccion3);

        }

        public void PrecargaDeAdmin()
        {
            Administrador admin1 = new Administrador("nachox30000@gmail.com", "nacho123");

            administradores.Add(admin1);

        }







    }
}
